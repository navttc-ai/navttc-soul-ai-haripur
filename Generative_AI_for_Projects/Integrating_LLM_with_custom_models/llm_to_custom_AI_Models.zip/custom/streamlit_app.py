import streamlit as st
from tensorflow.keras.models import load_model
import numpy as np
import joblib
from groq import Groq
import json
import pandas as pd

# --- Page Configuration ---
st.set_page_config(
    page_title="Heart Disease Prediction Chatbot",
    page_icon="❤️",
    layout="centered"
)

# --- Title and Description ---
st.title("❤️ Heart Disease Prediction Chatbot")
st.markdown("""
Welcome! I'm a chatbot powered by an AI model that can help you understand your risk of heart disease.
Please describe your medical parameters in the chat below. For example:
*_"I am a 52 year old male with a resting blood pressure of 130, cholesterol of 240, and a max heart rate of 150."_*
""")

# --- Load ML Model and Scaler ---
@st.cache_resource
def load_prediction_model():
    model = load_model('heart_disease_model.h5')
    scaler = joblib.load('scaler.joblib')
    # Feature names based on the training data columns
    feature_names = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
    return model, scaler, feature_names

model, scaler, feature_names = load_prediction_model()

# --- Initialize Session State ---
if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "How can I help you today?"}]

# --- Display Chat History ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- Main App Logic (to be continued) ---
# ... (previous code)

# --- Groq API Key ---
try:
    groq_api_key = st.secrets["GROQ_API_KEY"]
except:
    groq_api_key = st.sidebar.text_input("Enter your Groq API Key:", type="password")

if not groq_api_key:
    st.info("Please add your Groq API key to continue.")
    st.stop()

client = Groq(api_key=groq_api_key)

# ... (rest of the code)

# ... (previous code)

def get_structured_data(user_input):
    """
    Uses Groq LLM to parse user input into a structured dictionary.
    """
    system_prompt = f"""
    You are an expert data extraction assistant. Your task is to extract medical parameters
    from the user's text and return them as a JSON object. The required features are:
    {', '.join(feature_names)}.

    - The user will provide their data in natural language.
    - You must map their input to the correct feature names.
    - For binary features ('sex', 'fbs', 'exang'), use 1 for male/true/yes and 0 for female/false/no.
    - If a feature is not mentioned, set its value to 0.
    - Return ONLY the JSON object, with no other text or explanations.

    Example:
    User input: "I am a 55 year old man, BP 140/90, cholesterol 250, my fasting blood sugar is fine, and I don't get angina on exercise. Max heart rate 160."
    Your output:
    {{
      "age": 55, "sex": 1, "cp": 0, "trestbps": 140, "chol": 250,
      "fbs": 0, "restecg": 0, "thalach": 160, "exang": 0, "oldpeak": 0.0,
      "slope": 0, "ca": 0, "thal": 0
    }}
    """
    
    chat_completion = client.chat.completions.create(
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input},
        ],
        model="llama-3.1-8b-instant",
        temperature=0.0,
        response_format={"type": "json_object"},
    )
    
    response_content = chat_completion.choices[0].message.content
    try:
        return json.loads(response_content)
    except json.JSONDecodeError:
        st.error("Error: The LLM returned an invalid format. Please try rephrasing your input.")
        return None

# ... (rest of the code)
# ... (previous code)

def get_prediction_explanation(prediction_result):
    """
    Uses Groq LLM to generate a user-friendly explanation of the prediction.
    """
    if prediction_result == 1:
        prompt_text = "The model predicts a HIGH risk of heart disease. Please provide a brief, empathetic explanation for a non-technical user. Advise them to consult a doctor for a proper diagnosis. Do not give medical advice."
    else:
        prompt_text = "The model predicts a LOW risk of heart disease. Please provide a brief, reassuring explanation for a non-technical user. Encourage them to maintain a healthy lifestyle."

    chat_completion = client.chat.completions.create(
        messages=[
            {"role": "system", "content": "You are a helpful medical assistant AI. Your role is to explain prediction results clearly and kindly."},
            {"role": "user", "content": prompt_text},
        ],
        model="llama-3.1-8b-instant",
        temperature=0.5,
    )
    return chat_completion.choices[0].message.content

# --- Main App Logic ---
if prompt := st.chat_input("Describe your health parameters..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Display assistant response in a stream-like fashion
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""

        # Step 1: Parse user input
        message_placeholder.markdown("Parsing your input... ⚙️")
        structured_data = get_structured_data(prompt)
        
        if structured_data:
            message_placeholder.markdown("Analyzing your data with the ML model... 🧠")
            
            # Step 2: Prepare data for the model
            try:
                # Create a DataFrame to ensure feature order
                input_df = pd.DataFrame([structured_data])
                input_df = input_df[feature_names] # Ensure correct column order

                # Step 3: Scale the features
                input_scaled = scaler.transform(input_df)

                # Step 4: Make a prediction
                prediction_prob = model.predict(input_scaled)[0][0]
                prediction = 1 if prediction_prob > 0.5 else 0

                # Step 5: Get a friendly explanation
                message_placeholder.markdown("Generating an explanation... ✍️")
                explanation = get_prediction_explanation(prediction)
                
                # Display the final result
                result_md = f"""
                ### Prediction Result:
                - **Risk Level:** {'High Risk' if prediction == 1 else 'Low Risk'}
                - **Probability Score:** {prediction_prob:.2f}

                ---
                **Explanation:**
                {explanation}
                """
                message_placeholder.markdown(result_md)
                st.session_state.messages.append({"role": "assistant", "content": result_md})

            except Exception as e:
                error_message = f"An error occurred during prediction: {e}. Please ensure your input is clear and contains relevant medical terms."
                st.error(error_message)
                st.session_state.messages.append({"role": "assistant", "content": error_message})
        else:
            error_msg = "I couldn't understand the medical data in your message. Could you please try rephrasing it?"
            message_placeholder.markdown(error_msg)
            st.session_state.messages.append({"role": "assistant", "content": error_msg})
    