import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import joblib

# 1. Load the dataset
data = pd.read_csv('heart.csv')

# 2. Define features (X) and target (y)
X = data.drop('target', axis=1)
y = data['target']

# 3. Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. Build the Keras model
model = Sequential([
    Dense(32, activation='relu', input_shape=(X_train_scaled.shape[1],)),
    Dense(16, activation='relu'),
    Dense(1, activation='sigmoid')
])

# 6. Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 7. Train the model
model.fit(X_train_scaled, y_train, epochs=100, batch_size=10, verbose=0)

# 8. Save the model and the scaler
model.save('heart_disease_model.h5')
joblib.dump(scaler, 'scaler.joblib')

print("Model and scaler have been saved successfully!")

# Evaluate the model (optional)
loss, accuracy = model.evaluate(X_test_scaled, y_test)
print(f"Test Accuracy: {accuracy*100:.2f}%")